// eslint-disable-next-line @typescript-eslint/consistent-type-imports
export type CodemirrorBql = typeof import("./bql.ts");

// eslint-disable-next-line @typescript-eslint/consistent-type-imports
export type CodemirrorBeancount = typeof import("./beancount.ts");
